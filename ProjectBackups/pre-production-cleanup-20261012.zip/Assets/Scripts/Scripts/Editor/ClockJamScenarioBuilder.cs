using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.Rendering.Universal;

public static class ClockJamScenarioBuilder
{
    public const int PieceCount = 11;
    public const int ShadowRefCount = 9;
    public const int SunWaypointCount = 4;

    private const string ArtDir = "Assets/Assets/FinalReloj_export/";
    private const string RealScenePath = "Assets/Scenes/Scene-Gameplay.unity";

    private const float PPU = 100f;
    public const float CanvasWidth = 489f / PPU;
    public const float CanvasHeight = 275f / PPU;
    public const float SnapRadius = 1.15f;

    private const float AlphaThreshold = 0.5f;
    private const int MaxColliderPoints = 48;
    private const float MinColliderPointDistance = 0.008f;

    public const int OrderCielo = -30;
    public const int OrderSol = -29;
    public const int OrderFondo = -28;
    public const int OrderMarco = -20;
    public const int OrderFigura = -10;
    public const int OrderPieza = 0;
    public const int OrderCostura = 5;
    public const int OrderHoraYRango = 8;
    public const int OrderSombra = 10;
    private const int OrderFx = 20;

    private static readonly List<string> _temporarilyReadable = new List<string>();

    private static readonly string[] SeamFiles =
    {
        "1-2", "1-3", "1-7", "1-8", "1-10", "1-11", "2-3", "3-4", "3-10", "4-5",
        "4-8", "4-9", "4-10", "5-6", "5-8", "6-7", "7-8", "7-11", "8-9", "8-10", "8-11"
    };

    private static readonly Vector2[] DefaultSunPath =
    {
        new Vector2(-1.90f, -0.60f),
        new Vector2(-0.80f, 0.30f),
        new Vector2(0.55f, 0.45f),
        new Vector2(1.80f, -0.55f)
    };

    public static void BuildRemakeScene()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

        BackupExistingScene();
        UnityEngine.SceneManagement.Scene scene =
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        BuildCamera();
        BuildGlobalLight();
        BuildEventSystem();

        GameObject lienzoGo = new GameObject("Lienzo");
        Transform lienzo = lienzoGo.transform;
        lienzo.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
        lienzo.localScale = Vector3.one;

        MakeLayer(lienzo, "Cielo", "CieloRemake.png", OrderCielo);
        SpriteRenderer sol = MakeLayer(lienzo, "Sol", "SolRemake.png", OrderSol);
        MakeLayer(lienzo, "Fondo", "FondoRemake.png", OrderFondo);
        MakeLayer(lienzo, "Marco", "MarcoRemake.png", OrderMarco);
        SpriteRenderer figura = MakeLayer(lienzo, "Figura Completa", "FiguraCompletaRemake.png", OrderFigura);

        Transform piezasRoot = NewParent("Piezas", Vector3.zero, lienzo);
        Transform costurasRoot = NewParent("Costuras", Vector3.zero, lienzo);
        MakeLayer(lienzo, "Hora y Rango", "HoraYRangoRemake.png", OrderHoraYRango);
        SpriteRenderer sombra = MakeLayer(lienzo, "Sombra", "SombraRemake.png", OrderSombra);

        Transform sistema = NewParent("Sistema", Vector3.zero);
        ClockJamSolarClock clock = NewComponent<ClockJamSolarClock>(sistema, "SolarClock");

        GameObject pmGo = new GameObject("PuzzleManager");
        pmGo.transform.SetParent(sistema, false);
        ClockJamPuzzleManager pm = pmGo.AddComponent<ClockJamPuzzleManager>();

        Transform[] origenes = BuildOrigens(piezasRoot);
        ClockJamPiece[] pieces = BuildPieces(piezasRoot, pm, lienzo, origenes);
        BuildSeams(costurasRoot, pm, pieces);

        Transform sunWaypointsHost = NewParent("Waypoints Sol", Vector3.zero);
        Transform[] sunWaypoints = BuildSunWaypoints(sunWaypointsHost);
        Transform shadowRefsHost = NewParent("Referencias Sombra", Vector3.zero);
        Transform sombraOrigen = NewParent("Sombra Posicion Original", new Vector3(0.9f, -0.45f, 0f), shadowRefsHost);
        Transform[] shadowRefs = BuildShadowRefs(shadowRefsHost);

        GameObject sunCtlGo = new GameObject("Control Sol");
        sunCtlGo.transform.SetParent(sistema, false);
        SolarPathController sunCtl = sunCtlGo.AddComponent<SolarPathController>();
        sunCtl.clock = clock;
        sunCtl.sun = sol.transform;
        sunCtl.waypoints = sunWaypoints;
        sunCtl.curvaTiempo = AnimationCurve.Linear(0f, 0f, 1f, 1f);
        sunCtl.Refresh();

        GameObject shadowCtlGo = new GameObject("Control Sombra");
        shadowCtlGo.transform.SetParent(sistema, false);
        ShadowSweepController shadowCtl = shadowCtlGo.AddComponent<ShadowSweepController>();
        shadowCtl.clock = clock;
        shadowCtl.sombra = sombra.transform;
        shadowCtl.posicionOriginal = sombraOrigen;
        shadowCtl.referencias = shadowRefs;
        shadowCtl.curvaBarrido = AnimationCurve.Linear(0f, 0f, 1f, 1f);
        shadowCtl.CapturarPunta();
        shadowCtl.Refresh();

        GameObject wrathGo = new GameObject("WrathController");
        wrathGo.transform.SetParent(sistema, false);
        ClockJamWrathController wrath = wrathGo.AddComponent<ClockJamWrathController>();
        wrath.puzzleManager = pm;
        wrath.solarClock = clock;
        wrath.warningDuration = 3.5f;
        wrath.respawnTime = 15f;

        GameObject levelGo = new GameObject("LevelController");
        levelGo.transform.SetParent(sistema, false);
        ClockJamLevelController level = levelGo.AddComponent<ClockJamLevelController>();
        level.clock = clock;
        level.wrath = wrath;
        level.puzzleManager = pm;
        level.figura = figura.gameObject;
        level.piezasRoot = piezasRoot.gameObject;
        level.costurasRoot = costurasRoot.gameObject;

        figura.gameObject.SetActive(false);
        RestoreImporterState();

        EditorSceneManager.SaveScene(scene, RealScenePath);
        AddSceneToBuildSettings(RealScenePath);
        Debug.Log("Escenario Remake generado en: " + RealScenePath);
    }

    public static void RebuildPieceColliders()
    {
        ClockJamPiece[] pieces = UnityEngine.Object.FindObjectsByType<ClockJamPiece>(FindObjectsSortMode.None);
        if (pieces == null || pieces.Length == 0)
        {
            Debug.LogWarning("No hay piezas en la escena abierta.");
            return;
        }

        List<string> touched = new List<string>();
        int updated = 0;

        foreach (ClockJamPiece piece in pieces)
        {
            SpriteRenderer sr = piece != null ? piece.GetComponent<SpriteRenderer>() : null;
            if (sr == null || sr.sprite == null) continue;

            string path = AssetDatabase.GetAssetPath(sr.sprite);
            if (string.IsNullOrEmpty(path)) continue;

            TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer != null && !importer.isReadable)
            {
                importer.isReadable = true;
                importer.SaveAndReimport();
                touched.Add(path);
                sr.sprite = AssetDatabase.LoadAssetAtPath<Sprite>(path);
            }

            Vector2[][] paths = AlphaOutline(sr.sprite);
            if (paths == null)
            {
                Debug.LogWarning("Sin contorno de alfa para: " + path);
                continue;
            }

            PolygonCollider2D poly = piece.GetComponent<PolygonCollider2D>();
            if (poly == null) poly = piece.gameObject.AddComponent<PolygonCollider2D>();
            SetColliderPaths(poly, paths);
            updated++;
        }

        foreach (string path in touched)
        {
            TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer == null || !importer.isReadable) continue;
            importer.isReadable = false;
            importer.SaveAndReimport();
        }

        if (updated > 0) EditorSceneManager.MarkAllScenesDirty();
        Debug.Log("Colliders de alfa recalculados en " + updated + " pieza(s).");
    }

    private static Transform[] BuildOrigens(Transform piezasRoot)
    {
        Transform[] origenes = new Transform[PieceCount];
        for (int i = 0; i < PieceCount; i++)
        {
            GameObject go = new GameObject("Origen " + (i + 1));
            go.transform.SetParent(piezasRoot, false);
            go.transform.SetPositionAndRotation(DefaultOrigenPosition(i), DefaultOrigenRotation(i));
            go.transform.localScale = DefaultOrigenScale(i);
            origenes[i] = go.transform;
        }
        return origenes;
    }

    private static Vector3 DefaultOrigenPosition(int i)
    {
        float step = 360f / PieceCount;
        float rad = (-90f + i * step) * Mathf.Deg2Rad;
        return new Vector3(Mathf.Cos(rad) * 1.75f, Mathf.Sin(rad) * 0.95f, 0f);
    }

    private static Quaternion DefaultOrigenRotation(int i) => Quaternion.Euler(0f, 0f, 90f * (i % 4));

    private static Vector3 DefaultOrigenScale(int i) => Vector3.one * (0.55f + 0.05f * (i % 3));

    private static ClockJamPiece[] BuildPieces(Transform piezasRoot, ClockJamPuzzleManager pm,
        Transform lienzo, Transform[] origenes)
    {
        ClockJamPiece[] pieces = new ClockJamPiece[PieceCount];

        for (int i = 0; i < PieceCount; i++)
        {
            Sprite sprite = LoadSprite("Pieza" + (i + 1) + "Remake.png", true);

            GameObject go = new GameObject("Pieza " + (i + 1));
            go.transform.SetParent(piezasRoot, false);
            go.transform.SetPositionAndRotation(origenes[i].position, origenes[i].rotation);
            go.transform.localScale = origenes[i].localScale;

            SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            sr.sortingOrder = OrderPieza;

            PolygonCollider2D poly = go.AddComponent<PolygonCollider2D>();
            Vector2[][] paths = AlphaOutline(sprite);
            if (paths != null)
            {
                SetColliderPaths(poly, paths);
            }
            else
            {
                BoxCollider2D box = go.AddComponent<BoxCollider2D>();
                box.size = sprite != null ? sprite.bounds.size * 0.8f : new Vector2(1f, 1f);
                Debug.LogWarning("Pieza " + (i + 1) + ": sin contorno de alfa, se usó collider de caja.");
            }

            ClockJamPiece piece = go.AddComponent<ClockJamPiece>();
            piece.puzzleManager = pm;
            piece.snapTarget = lienzo;
            piece.origen = origenes[i];
            piece.snapRadius = SnapRadius;
            piece.fireEffect = MakeFx(go.transform, "Fx Humo", new Color(0.45f, 0.42f, 0.4f, 0.55f), 0.45f, 0.9f, 0.9f);
            piece.respawnEffect = MakeFx(go.transform, "Fx Hilos", new Color(1f, 0.85f, 0.3f, 0.9f), 0.12f, 2.2f, 1.2f, true);
            piece.weavingEffect = MakeFx(go.transform, "Fx Costura", new Color(0.95f, 0.9f, 0.6f, 0.8f), 0.08f, 1.6f, 0.8f, true);

            pieces[i] = piece;
        }
        return pieces;
    }

    private static void BuildSeams(Transform costurasRoot, ClockJamPuzzleManager pm, ClockJamPiece[] pieces)
    {
        List<TapestrySeam> seams = new List<TapestrySeam>();

        foreach (string file in SeamFiles)
        {
            string[] parts = file.Split('-');
            if (parts.Length != 2) continue;

            int a, b;
            if (!int.TryParse(parts[0], out a) || !int.TryParse(parts[1], out b)) continue;
            if (a < 1 || b < 1 || a > PieceCount || b > PieceCount) continue;

            Sprite sprite = LoadSprite(file + "Remake.png", false);
            if (sprite == null) continue;

            GameObject seam = new GameObject("Costura " + file);
            seam.transform.SetParent(costurasRoot, false);
            seam.SetActive(false);

            SpriteRenderer sr = seam.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            sr.sortingOrder = OrderCostura;

            seams.Add(new TapestrySeam
            {
                pieceA = pieces[a - 1],
                pieceB = pieces[b - 1],
                seamObject = seam
            });
        }

        pm.seams = seams.ToArray();
    }

    private static Transform[] BuildSunWaypoints(Transform host)
    {
        Transform[] waypoints = new Transform[SunWaypointCount];
        for (int i = 0; i < SunWaypointCount; i++)
        {
            Vector2 p = i < DefaultSunPath.Length ? DefaultSunPath[i] : Vector2.zero;
            GameObject go = new GameObject("Sol W" + (i + 1));
            go.transform.SetParent(host, false);
            go.transform.localPosition = p;
            waypoints[i] = go.transform;
        }
        return waypoints;
    }

    private static Transform[] BuildShadowRefs(Transform host)
    {
        Transform[] refs = new Transform[ShadowRefCount];
        for (int i = 0; i < ShadowRefCount; i++)
        {
            float u = i / (float)(ShadowRefCount - 1);
            float x = Mathf.Lerp(-1.85f, 1.85f, u);
            float y = -1.02f + 0.15f * Mathf.Sin(u * Mathf.PI);

            GameObject go = new GameObject("Sombra R" + (i + 1));
            go.transform.SetParent(host, false);
            go.transform.localPosition = new Vector3(x, y, 0f);
            refs[i] = go.transform;
        }
        return refs;
    }

    private static void BuildCamera()
    {
        GameObject go = new GameObject("Main Camera");
        go.tag = "MainCamera";
        go.transform.position = new Vector3(0f, 0f, -10f);
        Camera cam = go.AddComponent<Camera>();
        cam.orthographic = true;
        cam.orthographicSize = CanvasHeight * 0.5f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.05f, 0.05f, 0.08f);
        go.AddComponent<Physics2DRaycaster>();
    }

    private static void BuildGlobalLight()
    {
        GameObject go = new GameObject("Global Light 2D");
        Light2D light = go.AddComponent<Light2D>();
        light.lightType = Light2D.LightType.Global;
        light.intensity = 1f;
    }

    private static void BuildEventSystem()
    {
        GameObject go = new GameObject("EventSystem");
        go.AddComponent<EventSystem>();
        go.AddComponent<InputSystemUIInputModule>();
    }

    private static SpriteRenderer MakeLayer(Transform parent, string name, string file, int order)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
        go.transform.localScale = Vector3.one;

        SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = LoadSprite(file, false);
        sr.sortingOrder = order;
        return sr;
    }

    private static Transform NewParent(string name, Vector3 pos, Transform parent = null)
    {
        GameObject go = new GameObject(name);
        if (parent != null) go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        return go.transform;
    }

    private static T NewComponent<T>(Transform parent, string name) where T : Component
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        return go.AddComponent<T>();
    }

    private static ParticleSystem MakeFx(Transform parent, string name, Color color, float size, float speed, float lifetime, bool small = false)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        ParticleSystem ps = go.AddComponent<ParticleSystem>();

        ParticleSystem.MainModule main = ps.main;
        main.startColor = color;
        main.startSize = size;
        main.startSpeed = speed;
        main.startLifetime = lifetime;
        main.simulationSpace = ParticleSystemSimulationSpace.Local;
        main.loop = true;
        main.playOnAwake = false;

        ParticleSystem.EmissionModule em = ps.emission;
        em.rateOverTime = small ? 10f : 16f;

        ParticleSystem.ShapeModule shape = ps.shape;
        shape.shapeType = ParticleSystemShapeType.Sphere;
        shape.radius = small ? 0.2f : 0.4f;

        ParticleSystemRenderer rend = ps.GetComponent<ParticleSystemRenderer>();
        Shader sh = Shader.Find("Universal Render Pipeline/Particles/Unlit");
        if (sh == null) sh = Shader.Find("Sprites/Default");
        Material mat = new Material(sh);
        mat.mainTexture = MakeSoftTexture();
        rend.sharedMaterial = mat;
        rend.sortingOrder = OrderFx;
        ps.Stop();
        return ps;
    }

    private static Sprite LoadSprite(string fileName, bool needsReadable)
    {
        string path = ArtDir + fileName;
        TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
        if (importer != null)
        {
            bool dirty = false;
            if (importer.textureType != TextureImporterType.Sprite)
            {
                importer.textureType = TextureImporterType.Sprite;
                dirty = true;
            }
            if (importer.spriteImportMode != SpriteImportMode.Single)
            {
                importer.spriteImportMode = SpriteImportMode.Single;
                dirty = true;
            }
            if (!Mathf.Approximately(importer.spritePixelsPerUnit, PPU))
            {
                importer.spritePixelsPerUnit = PPU;
                dirty = true;
            }
            if (needsReadable && !importer.isReadable)
            {
                importer.isReadable = true;
                _temporarilyReadable.Add(path);
                dirty = true;
            }
            if (dirty) importer.SaveAndReimport();
        }

        Sprite sprite = AssetDatabase.LoadAssetAtPath<Sprite>(path);
        if (sprite == null) Debug.LogWarning("No se pudo cargar el sprite: " + path);
        return sprite;
    }

    private static void RestoreImporterState()
    {
        foreach (string path in _temporarilyReadable)
        {
            TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer == null || !importer.isReadable) continue;
            importer.isReadable = false;
            importer.SaveAndReimport();
        }
        _temporarilyReadable.Clear();
    }

    private static void SetColliderPaths(PolygonCollider2D poly, Vector2[][] paths)
    {
        poly.pathCount = paths.Length;
        for (int i = 0; i < paths.Length; i++)
            poly.SetPath(i, paths[i]);
    }

    private static Vector2[][] AlphaOutline(Sprite sprite)
    {
        if (sprite == null) return null;
        Texture2D tex = sprite.texture;
        if (tex == null) return null;

        Color32[] pixels;
        try
        {
            pixels = tex.GetPixels32();
        }
        catch (System.Exception e)
        {
            Debug.LogWarning("No se pudo leer la textura de " + sprite.name + ": " + e.Message);
            return null;
        }

        byte threshold = (byte)Mathf.Clamp(Mathf.RoundToInt(AlphaThreshold * 255f), 1, 255);
        List<Vector2> contour = TraceContour(pixels, tex.width, tex.height, threshold, sprite.pixelsPerUnit, sprite.pivot);
        if (contour == null) return null;

        List<Vector2> simplified = SimplifyRdp(contour, MinColliderPointDistance);
        if (simplified == null) return null;
        simplified = CapPoints(simplified, MaxColliderPoints);
        if (simplified == null || simplified.Count < 3) return null;

        return new[] { simplified.ToArray() };
    }

    private static readonly Vector2Int[] MooreNeighborhood =
    {
        new Vector2Int(1, 0), new Vector2Int(1, 1), new Vector2Int(0, 1), new Vector2Int(-1, 1),
        new Vector2Int(-1, 0), new Vector2Int(-1, -1), new Vector2Int(0, -1), new Vector2Int(1, -1)
    };

    private static List<Vector2> TraceContour(Color32[] pixels, int width, int height, byte threshold, float ppu, Vector2 pivot)
    {
        int startX = -1, startY = -1;
        for (int y = height - 1; y >= 0 && startX < 0; y--)
        {
            for (int x = 0; x < width; x++)
            {
                if (pixels[y * width + x].a >= threshold)
                {
                    startX = x;
                    startY = y;
                    break;
                }
            }
        }
        if (startX < 0) return null;

        float scale = 1f / (Mathf.Approximately(ppu, 0f) ? 100f : ppu);
        List<Vector2> contour = new List<Vector2>();

        int cx = startX, cy = startY;
        int backX = startX - 1, backY = startY;
        int maxSteps = width * height;

        while (contour.Count <= maxSteps)
        {
            contour.Add(new Vector2((cx + 0.5f - pivot.x) * scale, (cy + 0.5f - pivot.y) * scale));

            int backIndex = NeighborIndex(backX - cx, backY - cy);
            bool moved = false;

            for (int k = 1; k <= 8; k++)
            {
                Vector2Int n = MooreNeighborhood[(backIndex + k) % 8];
                int nx = cx + n.x, ny = cy + n.y;
                if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
                if (pixels[ny * width + nx].a < threshold) continue;

                Vector2Int prev = MooreNeighborhood[((backIndex + k) + 7) % 8];
                backX = cx + prev.x;
                backY = cy + prev.y;
                cx = nx;
                cy = ny;
                moved = true;
                break;
            }

            if (!moved) break;
            if (cx == startX && cy == startY) break;
        }

        return contour.Count >= 3 ? contour : null;
    }

    private static int NeighborIndex(int dx, int dy)
    {
        for (int i = 0; i < MooreNeighborhood.Length; i++)
            if (MooreNeighborhood[i].x == dx && MooreNeighborhood[i].y == dy) return i;
        return 0;
    }

    private static List<Vector2> SimplifyRdp(List<Vector2> points, float epsilon)
    {
        if (points == null || points.Count < 3) return null;
        bool[] keep = new bool[points.Count];
        keep[0] = true;
        keep[points.Count - 1] = true;
        Rdp(points, 0, points.Count - 1, epsilon * epsilon, keep);

        List<Vector2> result = new List<Vector2>();
        for (int i = 0; i < points.Count; i++)
            if (keep[i]) result.Add(points[i]);
        return result;
    }

    private static void Rdp(List<Vector2> points, int first, int last, float epsSq, bool[] keep)
    {
        if (last <= first + 1) return;

        Vector2 a = points[first];
        Vector2 ab = points[last] - a;
        float lenSq = ab.sqrMagnitude;
        float maxDist = -1f;
        int index = -1;

        for (int i = first + 1; i < last; i++)
        {
            float d;
            if (lenSq < 1e-12f)
            {
                d = (points[i] - a).sqrMagnitude;
            }
            else
            {
                float t = Mathf.Clamp01(Vector2.Dot(points[i] - a, ab) / lenSq);
                d = (points[i] - (a + ab * t)).sqrMagnitude;
            }
            if (d > maxDist)
            {
                maxDist = d;
                index = i;
            }
        }

        if (maxDist > epsSq && index > 0)
        {
            keep[index] = true;
            Rdp(points, first, index, epsSq, keep);
            Rdp(points, index, last, epsSq, keep);
        }
    }

    private static List<Vector2> CapPoints(List<Vector2> points, int maxPoints)
    {
        if (points == null) return null;
        if (points.Count <= maxPoints) return points;

        List<Vector2> reduced = new List<Vector2>();
        float stride = (float)points.Count / maxPoints;
        for (int i = 0; i < maxPoints; i++)
            reduced.Add(points[Mathf.Clamp(Mathf.RoundToInt(i * stride), 0, points.Count - 1)]);
        return reduced;
    }

    private static void BackupExistingScene()
    {
        if (!AssetDatabase.LoadAssetAtPath<SceneAsset>(RealScenePath)) return;
        const string backupDir = "Assets/Scenes/_Backup";
        if (!AssetDatabase.IsValidFolder(backupDir))
            AssetDatabase.CreateFolder("Assets/Scenes", "_Backup");

        string stamp = System.DateTime.Now.ToString("yyyyMMdd-HHmmss");
        string backup = backupDir + "/Scene-Gameplay-" + stamp + ".unity";
        if (AssetDatabase.CopyAsset(RealScenePath, backup))
            Debug.Log("Copia de seguridad de la escena anterior en: " + backup);
    }

    private static void AddSceneToBuildSettings(string path)
    {
        EditorBuildSettingsScene[] scenes = EditorBuildSettings.scenes;
        foreach (EditorBuildSettingsScene s in scenes)
            if (s.path == path) return;
        System.Array.Resize(ref scenes, scenes.Length + 1);
        scenes[scenes.Length - 1] = new EditorBuildSettingsScene(path, true);
        EditorBuildSettings.scenes = scenes;
    }

    private static Texture2D MakeSoftTexture()
    {
        int size = 64;
        Texture2D tex = new Texture2D(size, size);
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float d = Vector2.Distance(new Vector2(x, y), new Vector2(size * 0.5f, size * 0.5f)) / (size * 0.5f);
                float a = Mathf.Clamp01(1f - d);
                a *= a;
                tex.SetPixel(x, y, new Color(1f, 1f, 1f, a));
            }
        }
        tex.Apply();
        return tex;
    }
}
